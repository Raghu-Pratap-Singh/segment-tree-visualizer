# SEGMENT_TREE_VISUALIZER/__init__.py

from .main import StaticSegmentTree, DynamicSegmentTree